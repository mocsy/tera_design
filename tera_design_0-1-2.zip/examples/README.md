# SB Admin2
Copy tera_design executable to the example/sbmadmin2 directory and start it
